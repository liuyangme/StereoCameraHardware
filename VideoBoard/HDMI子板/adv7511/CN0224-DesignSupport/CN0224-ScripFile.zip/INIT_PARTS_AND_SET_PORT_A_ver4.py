import time
import wx
import os

writeReg = topwin.devDriver.writeReg 
writeRegs = topwin.devDriver.writeRegs 
readReg = topwin.devDriver.readReg 
readRegs = topwin.devDriver.readRegs 

def set_switch_u43():
    writeRegs(0xE8, 0x06, [0xFE,], [1, 8]) #  SET 0.0 TO OUTPUT
    writeRegs(0xE8, 0x02, [0xFF,], [1, 8]) #  SET 0.0 LOW (U43)

def set_switch_u1():
    writeRegs(0xE8, 0x06, [0xFE,], [1, 8]) #  SET 0.0 TO OUTPUT
    writeRegs(0xE8, 0x02, [0xFE,], [1, 8]) #  U1

def set_selected_adv7612(tristate=1, dll_phase=3):
    writeRegs(0x98, 0xFF, [0x80,], [1, 8]) #  I2C reset
    writeRegs(0x98, 0xF4, [0x80,0x7C,], [1, 8]) #  CEC, Infoframe
    writeRegs(0x98, 0xF8, [0x4C,0x64,0x6C,0x68,], [1, 8]) #  DPLL, KSV, EDID, HDMI, 
    writeRegs(0x98, 0xFD, [0x44,], [1, 8]) #  CP
    writeRegs(0x64, 0x77, [0x0,], [1, 8]) #  Disable the Internal EDID for all ports
    writeRegs(0x6C, 0x00, [0x0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x0,0x6,0x8F,0x7,0x11,0x1,0x0,0x0,0x0,0x17,0x11,0x1,0x3,0x80,0xC,0x9,], [1, 8])
    writeRegs(0x6C, 0x17, [0x78,0xA,0x1E,0xAC,0x98,0x59,0x56,0x85,0x28,0x29,0x52,0x57,0x0,0x0,0x0,0x1,0x1,0x1,0x1,0x1,0x1,0x1,0x1,], [1, 8])
    writeRegs(0x6C, 0x2E, [0x1,0x1,0x1,0x1,0x1,0x1,0x1,0x1,0x8C,0xA,0xD0,0x8A,0x20,0xE0,0x2D,0x10,0x10,0x3E,0x96,0x0,0x81,0x60,0x0,], [1, 8])
    writeRegs(0x6C, 0x45, [0x0,0x0,0x18,0x1,0x1D,0x80,0x18,0x71,0x1C,0x16,0x20,0x58,0x2C,0x25,0x0,0x81,0x49,0x0,0x0,0x0,0x9E,0x0,0x0,], [1, 8])
    writeRegs(0x6C, 0x5C, [0x0,0xFC,0x0,0x56,0x41,0x2D,0x31,0x38,0x30,0x39,0x41,0xA,0x20,0x20,0x20,0x20,0x0,0x0,0x0,0xFD,0x0,0x17,0x3D,], [1, 8])
    writeRegs(0x6C, 0x73, [0xD,0x2E,0x11,0x0,0xA,0x20,0x20,0x20,0x20,0x20,0x20,0x1,0x1C,0x2,0x3,0x3D,0x71,0x4D,0x82,0x5,0x4,0x1,0x10,], [1, 8])
    writeRegs(0x6C, 0x8A, [0x11,0x14,0x13,0x1F,0x6,0x15,0x3,0x12,0x3E,0xF,0x7F,0x7,0x17,0x1F,0x38,0x1F,0x7,0x30,0x2F,0x7,0x72,0x3F,0x7F,], [1, 8])
    writeRegs(0x6C, 0xA1, [0x72,0x4F,0x7F,0x0,0x57,0x7F,0x0,0x5F,0x7F,0x1,0x37,0x7F,0x72,0x67,0x7F,0x0,0x83,0x4F,0x0,0x0,0x67,0x3,0xC,], [1, 8])
    writeRegs(0x6C, 0xB8, [0x0,0x10,0x0,0xB8,0x2D,0x1,0x1D,0x0,0x72,0x51,0xD0,0x1E,0x20,0x6E,0x28,0x55,0x0,0x81,0x49,0x0,0x0,0x0,0x1E,], [1, 8])
    writeRegs(0x6C, 0xCF, [0xD6,0x9,0x80,0xA0,0x20,0xE0,0x2D,0x10,0x10,0x60,0xA2,0x0,0x81,0x60,0x0,0x8,0x8,0x18,0x8C,0xA,0xD0,0x90,0x20,], [1, 8])
    writeRegs(0x6C, 0xE6, [0x40,0x31,0x20,0xC,0x40,0x55,0x0,0x81,0x60,0x0,0x0,0x0,0x18,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,], [1, 8])
    writeRegs(0x6C, 0xFD, [0x0,0x0,0x46,], [1, 8])
    writeRegs(0x64, 0x77, [0x0,], [1, 8]) #  Set the Most Significant Bit of the SPA location to 0
    writeRegs(0x64, 0x52, [0x20,0x0,], [1, 8]) #  Set the SPA for port B
    writeRegs(0x64, 0x70, [0x9E,], [1, 8]) #  Set the Least Significant Byte of the SPA location
    writeRegs(0x64, 0x74, [0x3,], [1, 8]) # Enable the Internal EDID for ports, END OF EDID
    writeRegs(0x98, 0x01, [0x6,0x12,0x42,], [1, 8]) #  Prim_Mode =110b HDMI-GR, Auto CSC, RGB out, NO op_656 bit, 36 bit SDR 444 Mode 0
    writeRegs(0x98, 0x05, [0x28,0xA6,], [1, 8]) #  AV Codes Off, Invert VS,HS pins
    writeRegs(0x98, 0x0B, [0x44,0x42,], [1, 8]) #  Power up part

    # setting tristate
    if (tristate):
        writeRegs(0x98, 0x14, [0x3F,0xBE,], [1, 8]) # Max drive Strength, Tristate Pins
    else:
        writeRegs(0x98, 0x14, [0x3F,0x80,], [1, 8]) #  Max Drive Strength, Disable Tristate of Pins

    # setting dll_phase
    reg_io_0x19 = 0x80 | dll_phase;
    writeRegs(0x98, 0x19, [reg_io_0x19,], [1, 8]) #  LLC DLL phase
    
    writeRegs(0x98, 0x33, [0x40,], [1, 8]) #  LLC DLL enable
    writeRegs(0x44, 0xBA, [0x1,], [1, 8]) #  Set HDMI FreeRun
    writeRegs(0x64, 0x40, [0x81,], [1, 8]) #  Disable HDCP 1.1 features
    writeRegs(0x68, 0x9B, [0x3,], [1, 8]) #  ADI recommended setting
    writeRegs(0x68, 0x00, [0x8,], [1, 8]) #  Set HDMI Input Port A (BG_MEAS_PORT_SEL = 001b)
    writeRegs(0x68, 0x02, [0x3,], [1, 8]) #  Enable Ports A & B in background mode
    writeRegs(0x68, 0x83, [0xFC,], [1, 8]) #  Enable clock terminators for port A & B
    writeRegs(0x68, 0x6F, [0x8,], [1, 8]) #  ADI recommended setting
    writeRegs(0x68, 0x85, [0x1F,], [1, 8]) #  ADI recommended setting
    writeRegs(0x68, 0x87, [0x70,], [1, 8]) #  ADI recommended setting
    writeRegs(0x68, 0x8D, [0x4,0x1E,], [1, 8]) #  LFG Port A, HFG Port A
    writeRegs(0x68, 0x1A, [0x8A,], [1, 8]) #  unmute audio
    writeRegs(0x68, 0x57, [0xDA,0x1,], [1, 8]) #  ADI recommended setting
    writeRegs(0x68, 0x75, [0x10,], [1, 8]) #  DDC drive strength
    writeRegs(0x68, 0x90, [0x4,0x1E,], [1, 8]) #  LFG Port B, HFG Port B

def set_adv7511(addr=0x72):
    writeRegs(addr, 0x01, [0x0,0x10,0x0,], [1, 8]) #  Set 'N' value at 4096
    writeRegs(addr, 0x14, [0x70,0x30,0x60,], [1, 8]) #  8 ch, Input 444 (RGB or YCrCb) with Separate Syncs, 32kHz fs, Output format 444, 36-bit input
    writeRegs(addr, 0x18, [0x46,], [1, 8]) #  Disable CSC
    writeRegs(addr, 0x40, [0x80,0x10,], [1, 8]) #  General control packet enable, Power down control
    writeRegs(addr, 0x49, [0x0,], [1, 8]) #  8-BITS
    writeRegs(addr, 0x4C, [0x6,], [1, 8]) #  12 bit Output
    writeRegs(addr, 0x96, [0x20,], [1, 8]) #  HPD interrupt clear
    writeRegs(addr, 0x55, [0x0,0x8,], [1, 8]) #  Set RGB 444 in AVI infoframe, Set active format aspect
    writeRegs(addr, 0x73, [0x7,], [1, 8]) #  Info frame Ch count to 8
    writeRegs(addr, 0x76, [0x1F,], [1, 8]) #  Set speaker allocation for 8 channels
    writeRegs(addr, 0x98, [0x3,0x2,], [1, 8]) #  ADI recommended write, ADI recommended write - lock count limit
    writeRegs(addr, 0x9C, [0x30,0x61,], [1, 8]) #  PLL filter R1 value, Set clock divide
    writeRegs(addr, 0xA2, [0xA4,0xA4,], [1, 8]) #  ADI recommended write, ADI Recommended Write
    writeRegs(addr, 0xA5, [0x4,], [1, 8]) #  ADI Recommended Write
    writeRegs(addr, 0xAB, [0x40,], [1, 8]) #  ADI Recommended Write
    writeRegs(addr, 0xAF, [0x16,], [1, 8]) #  Select HDMI mode
    writeRegs(addr, 0xBA, [0x60,], [1, 8]) #  No clock delay
    writeRegs(addr, 0xD1, [0xFF,], [1, 8]) #  ADI Recommended Write
    writeRegs(addr, 0xDE, [0xD8,], [1, 8]) #  ADI recommended write
    writeRegs(addr, 0xE4, [0x60,], [1, 8]) #  VCO_Swing_Reference_Voltage
    writeRegs(addr, 0xFA, [0x7D,], [1, 8]) #  Nbr of times to look for good phase

def tristate_selected_adv7612():
    writeRegs(0x98, 0x15, [0xBE,], [1, 8]) #  TRISTATE OUTPUTS
    
def untristate_selected_adv7612():
    writeRegs(0x98, 0x15, [0x80,], [1, 8]) #  TRISTATE OUTPUTS
    
def switch_to_port_a():
    set_switch_u1()
    tristate_selected_adv7612()
    set_switch_u43()
    writeRegs(0x68, 0x00, [0x8,], [1, 8]) #  Set HDMI Input Port A
    untristate_selected_adv7612()

def switch_to_port_b():
    set_switch_u1()
    tristate_selected_adv7612()
    set_switch_u43()
    writeRegs(0x68, 0x00, [0x9,], [1, 8]) #  Set HDMI Input Port B
    untristate_selected_adv7612()

def switch_to_port_c():
    set_switch_u43()
    tristate_selected_adv7612()
    set_switch_u1()
    writeRegs(0x68, 0x00, [0x8,], [1, 8]) #  Set HDMI Input Port C
    untristate_selected_adv7612()

def switch_to_port_d():
    set_switch_u43()
    tristate_selected_adv7612()
    set_switch_u1()
    writeRegs(0x68, 0x00, [0x9,], [1, 8]) #  Set HDMI Input Port D
    untristate_selected_adv7612()


"""
set_switch_u43()
set_selected_adv7612(tristate=0, dll_phase=26)
set_switch_u1()
set_selected_adv7612(tristate=1, dll_phase=26)
#set_adv7511(0x72)
set_adv7511(0x7A)

if 1:
    switch_to_port_a()
    time.sleep(5)
    switch_to_port_b()
    time.sleep(5)
    switch_to_port_c()
    time.sleep(5)
    switch_to_port_d()

topwin.ReadCurrentInterface()
"""

class MainWindow(wx.Frame):
    def __init__(self, parent, title):
        self.dirname=''
        self.parts_programmed = False # weree parts already programmed?
		
        # A "-1" in the size parameter instructs wxWidgets to use the default size.
        # In this case, we select 200px width and the default height.
        wx.Frame.__init__(self, parent, title=title, size=(400,-1))
        self.control = wx.TextCtrl(self, size=(-1, 200), style=wx.TE_MULTILINE|wx.TE_READONLY)
        self.CreateStatusBar() # A Statusbar in the bottom of the window

        # Setting up the menu.
        filemenu= wx.Menu()
        #menuOpen = filemenu.Append(wx.ID_OPEN, "&Open"," Open a file to edit")
        menuAbout= filemenu.Append(wx.ID_ABOUT, "&About"," Information about this program")
        menuExit = filemenu.Append(wx.ID_EXIT,"E&xit"," Terminate the program")

        # Creating the menubar.
        menuBar = wx.MenuBar()
        menuBar.Append(filemenu,"&File") # Adding the "filemenu" to the MenuBar
        self.SetMenuBar(menuBar)  # Adding the MenuBar to the Frame content.

        # Events.
        #self.Bind(wx.EVT_MENU, self.OnOpen, menuOpen)
        self.Bind(wx.EVT_MENU, self.OnExit, menuExit)
        self.Bind(wx.EVT_MENU, self.OnAbout, menuAbout)

        self.sizer2 = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer3 = wx.BoxSizer(wx.HORIZONTAL)
        #self.buttons = []
        #for i in range(0, 6):
        #    self.buttons.append(wx.Button(self, -1, "Button &"+str(i)))
        #    self.sizer2.Add(self.buttons[i], 1, wx.EXPAND)
		
        buttonPortA = wx.Button(self, -1, "Port A", size=(150,-1))
        buttonPortB = wx.Button(self, -1, "Port B", size=(150,-1))
        buttonPortC = wx.Button(self, -1, "Port C", size=(150,-1))
        buttonPortD = wx.Button(self, -1, "Port D", size=(150,-1))
        buttonInit = wx.Button(self, -1, "Init", size=(150,-1))

        buttonClear = wx.Button(self, -1, "Clear", size=(150,-1))
        buttonQuit = wx.Button(self, -1, "Close", size=(150,-1))
        self.Bind(wx.EVT_BUTTON, self.OnPortA, buttonPortA)
        self.Bind(wx.EVT_BUTTON, self.OnPortB, buttonPortB)
        self.Bind(wx.EVT_BUTTON, self.OnPortC, buttonPortC)
        self.Bind(wx.EVT_BUTTON, self.OnPortD, buttonPortD)
        self.Bind(wx.EVT_BUTTON, self.Start, buttonInit)
		
        self.Bind(wx.EVT_BUTTON, self.OnClear, buttonClear)        
        self.Bind(wx.EVT_BUTTON, self.OnExit, buttonQuit)
		
        self.Bind(wx.EVT_MENU, self.OnAbout, menuAbout)
        self.sizer2.Add(buttonPortA, 1, wx.EXPAND)
        self.sizer2.Add(buttonPortB, 1, wx.EXPAND)
        self.sizer2.Add(buttonPortC, 1, wx.EXPAND)
        self.sizer2.Add(buttonPortD, 1, wx.EXPAND)

        self.sizer3.Add(buttonInit, 1, wx.EXPAND)
        self.sizer3.Add(buttonClear, 1, wx.EXPAND)        
        self.sizer3.Add(buttonQuit, 1, wx.EXPAND)
		
        # Use some sizers to see layout options
        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer.Add(self.control, 1, wx.EXPAND)
        self.sizer.Add(self.sizer2, 0, wx.EXPAND)
        self.sizer.Add(self.sizer3, 0, wx.EXPAND)
		
        #Layout sizers
        self.SetSizer(self.sizer)
        self.SetAutoLayout(1)
        self.sizer.Fit(self)
        self.Show()

		
    def Start(self,e):
        set_switch_u43()
        set_selected_adv7612(tristate=0, dll_phase=26)
        self.control.AppendText("ADV7612 (U43) programmed to receive data.\n")
        set_switch_u1()
        set_selected_adv7612(tristate=1, dll_phase=26)
        self.control.AppendText("ADV7612 (U1) programmed to receive data.\n")
        #set_adv7511(0x72) # SECOND (UNUSED BY DEFAULT)
        set_adv7511(0x7A)
        self.parts_programmed = True

    def OnAbout(self,e):
        # Create a message dialog box
        dlg = wx.MessageDialog(self, " A sample editor \n in wxPython", "About Sample Editor", wx.OK)
        dlg.ShowModal() # Shows it
        dlg.Destroy() # finally destroy it when finished.

    def OnClear(self,e):
        # Create a message dialog box
        self.control.Clear()
		
    def OnPortA(self,e):
        if (not self.parts_programmed):
            self.Start()
        switch_to_port_a()
        self.control.AppendText("Switched to Port A.\n")

    def OnPortB(self,e):
        if (not self.parts_programmed):
            self.Start()
        switch_to_port_b()
        self.control.AppendText("Switched to Port B:\n")

    def OnPortC(self,e):
        if (not self.parts_programmed):
            self.Start()
        switch_to_port_c()
        self.control.AppendText("Switched to Port C:\n")

    def OnPortD(self,e):
        if (not self.parts_programmed):
            self.Start()
        switch_to_port_d()
        self.control.AppendText("Switched to Port D:\n")

    def OnExit(self,e):
        self.Close(True)  # Close the frame.		

app = wx.App(False)
frame = MainWindow(None, "Sample editor")
app.MainLoop()


